#!/usr/bin/env python3
"""
Offline iframe/embed URL extractor for browser capture folders.

The default mode is intentionally conservative:
- reads saved capture artifacts from disk
- skips cookies, auth tokens, and request headers
- reports iframe/embed/page references
- excludes direct media playlist/segment URLs unless --include-media is set

Use live URL fetching only for pages you own or are authorized to analyze.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime
from html import escape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlparse
from urllib.request import Request, urlopen


DEFAULT_CAPTURE_DIR = Path(r"C:\Users\AC\primesrc")
DEFAULT_MAIN_URL = "https://primesrc.me/embed/movie?tmdb=1358005"
DEFAULT_HTML_OUTPUT = Path("primsrc.html")
DEFAULT_XLSX_OUTPUT = Path("primesc.xlsx")
DEFAULT_URL_FILE = Path("multiple_primesrc.txt")
RESULT_HEADERS = ["serial_no", "movie_name", "server_name", "api_full_url_key", "key", "primesrc_main_url_tmdb"]

SENSITIVE_NAMES = {
    "auth_tokens.json",
    "cookies.json",
    "all_request_headers.json",
}

MEDIA_EXTENSIONS = (
    ".m3u8",
    ".mpd",
    ".mp4",
    ".m4v",
    ".webm",
    ".mov",
    ".avi",
    ".ts",
    ".m4s",
    ".vtt",
    ".srt",
)

URL_RE = re.compile(
    r"""(?ix)
    \b
    (?:
        https?://
        |
        //
    )
    [^\s"'<>\\)]+
    """
)

PATH_RE = re.compile(r"""(?i)^/(?:embed|e|v|video|player|watch|stream|api|l|s)(?:/|\?|$)""")

EMBED_WORDS = (
    "embed",
    "iframe",
    "player",
    "server",
    "source",
    "src",
    "url",
    "link",
    "file",
)

JSON_CONTEXT_WORDS = (
    "embed",
    "iframe",
    "player",
    "server",
)

MAIN_URL_RE = re.compile(r"https://primesrc\.me/embed/(?:movie|tv)\?[^\"'\\\s<>]+")
TMDB_ID_RE = re.compile(r"^\d+$")


@dataclass(frozen=True)
class Finding:
    kind: str
    url: str
    source: str
    detail: str = ""
    label: str = ""


@dataclass
class ServerOption:
    index: int
    key: str = ""
    title: str = ""
    file_size: str = ""
    quality: str = ""
    audio_type: str = ""
    audio_language: str = ""
    api_url: str = ""
    link: str = ""
    host: str = ""
    host_id: str = ""
    link_error: str = ""


@dataclass
class ServerEntry:
    name: str
    options: list[ServerOption]
    selected: bool = False


class EmbedHTMLParser(HTMLParser):
    def __init__(self, source: str, base_url: str | None, include_media: bool) -> None:
        super().__init__(convert_charrefs=True)
        self.source = source
        self.base_url = base_url
        self.include_media = include_media
        self.findings: list[Finding] = []
        self._last_anchor: dict[str, str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = {k.lower(): (v or "") for k, v in attrs}
        lower_attrs = " ".join(f"{k}={v}" for k, v in attr_map.items()).lower()

        if tag in {"iframe", "embed", "object"}:
            for name in ("src", "data", "data-src", "data-url", "data-href"):
                self._add_attr(tag, name, attr_map.get(name))
            return

        if tag in {"source", "video", "script"}:
            for name in ("src", "data-src"):
                self._add_attr(tag, name, attr_map.get(name))
            return

        if tag == "a":
            self._last_anchor = attr_map
            href = attr_map.get("href")
            if href and any(word in lower_attrs for word in EMBED_WORDS):
                self._add_attr(tag, "href", href)
            return

        if any(word in lower_attrs for word in EMBED_WORDS):
            for name in ("src", "href", "data", "data-src", "data-url", "data-href", "data-link"):
                self._add_attr(tag, name, attr_map.get(name))

    def handle_data(self, data: str) -> None:
        if not self._last_anchor:
            return
        text = " ".join(data.split())
        if not text:
            return
        href = self._last_anchor.get("href", "")
        lower = f"{text} {' '.join(self._last_anchor.values())}".lower()
        if href and any(word in lower for word in EMBED_WORDS):
            self._add("html-anchor", href, "anchor text", label=text[:80])

    def handle_endtag(self, tag: str) -> None:
        if tag == "a":
            self._last_anchor = None

    def _add_attr(self, tag: str, attr: str, value: str | None) -> None:
        if value:
            self._add(f"html-{tag}", value, attr)

    def _add(self, kind: str, raw_url: str, detail: str, label: str = "") -> None:
        url = normalize_url(raw_url, self.base_url)
        if not url or (not self.include_media and is_media_url(url)):
            return
        if is_url_or_interesting_path(url):
            self.findings.append(Finding(kind=kind, url=url, source=self.source, detail=detail, label=label))


class ServerMenuHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.servers: list[ServerEntry] = []
        self._current: ServerEntry | None = None
        self._current_option: ServerOption | None = None
        self._capture_name = False
        self._capture_quality = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "div":
            return
        attr_map = {key.lower(): (value or "") for key, value in attrs}
        classes = set(attr_map.get("class", "").split())

        if "server-menu-item" in classes:
            self._current = ServerEntry(name="", options=[], selected="selected" in classes)
            self.servers.append(self._current)
            return

        if self._current is None:
            return

        if "server-menu-item-name" in classes:
            self._capture_name = True
            return

        if "server-menu-item-quality" in classes:
            self._capture_quality = True
            return

        if "server-menu-item-option" in classes:
            title = " ".join(attr_map.get("title", "").split())
            self._current_option = ServerOption(index=len(self._current.options) + 1, title=title)
            self._current.options.append(self._current_option)

    def handle_data(self, data: str) -> None:
        text = " ".join(data.split())
        if not text or self._current is None:
            return

        if self._capture_quality:
            if self._current.options:
                self._current.options[-1].file_size = text
            return

        if self._capture_name and not text.isdigit():
            self._current.name = text

    def handle_endtag(self, tag: str) -> None:
        if tag != "div":
            return
        if self._capture_quality:
            self._capture_quality = False
            return
        if self._capture_name:
            self._capture_name = False
            return
        if self._current_option is not None:
            self._current_option = None


class ResultTableHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[dict[str, str]] = []
        self._current_row: dict[str, str] | None = None
        self._current_label = ""
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = {key.lower(): (value or "") for key, value in attrs}
        if tag == "tr":
            self._current_row = {}
            return
        if tag == "td" and self._current_row is not None:
            self._current_label = attr_map.get("data-label", "")
            self._parts = []

    def handle_data(self, data: str) -> None:
        if self._current_row is not None and self._current_label:
            self._parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "td" and self._current_row is not None and self._current_label:
            self._current_row[self._current_label] = " ".join("".join(self._parts).split())
            self._current_label = ""
            self._parts = []
            return
        if tag == "tr" and self._current_row is not None:
            if any(self._current_row.get(header, "") for header in RESULT_HEADERS):
                self.rows.append({header: self._current_row.get(header, "") for header in RESULT_HEADERS})
            self._current_row = None


def normalize_url(raw: str, base_url: str | None = None) -> str:
    value = raw.strip().strip("'\"")
    value = re.sub(r"^(?:GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+", "", value, flags=re.I)
    if not value or value.startswith(("javascript:", "data:", "blob:", "about:")):
        return ""
    if value.startswith("//"):
        value = "https:" + value
    if base_url and value.startswith("/"):
        value = urljoin(base_url, value)
    return value


def is_media_url(url: str) -> bool:
    path = urlparse(url).path.lower()
    return path.endswith(MEDIA_EXTENSIONS)


def is_url_or_interesting_path(url: str) -> bool:
    return bool(urlparse(url).scheme in {"http", "https"} or PATH_RE.search(url))


def looks_embed_related(value: str, key_path: str) -> bool:
    lower = f"{key_path} {value}".lower()
    if URL_RE.search(value) or PATH_RE.search(value):
        return any(word in lower for word in JSON_CONTEXT_WORDS) or "/embed" in lower
    return False


def read_text(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return path.read_text(encoding=encoding, errors="replace")
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="replace")


def iter_capture_files(capture_dir: Path) -> list[Path]:
    wanted_suffixes = {".html", ".json", ".jsonl", ".js"}
    files: list[Path] = []
    for path in capture_dir.rglob("*"):
        if not path.is_file() or path.name in SENSITIVE_NAMES:
            continue
        if path.name.endswith("_report.json") or path.name in {"embed_report.json", "server_list.json"}:
            continue
        if path.suffix.lower() in wanted_suffixes:
            files.append(path)
    return sorted(files)


def extract_from_html(path: Path, text: str, include_media: bool) -> list[Finding]:
    parser = EmbedHTMLParser(str(path), infer_base_url_from_capture_name(path), include_media)
    parser.feed(text)
    findings = list(parser.findings)
    findings.extend(extract_urls_from_text(path, text, include_media))
    return findings


def infer_base_url_from_capture_name(path: Path) -> str | None:
    stem = path.stem
    if "_" not in stem:
        return None
    host = stem.split("_", 1)[0]
    if "." not in host:
        return None
    return f"https://{host}/"


def extract_urls_from_text(path: Path, text: str, include_media: bool) -> list[Finding]:
    findings: list[Finding] = []
    for match in URL_RE.finditer(text):
        url = normalize_url(match.group(0))
        if not url or (not include_media and is_media_url(url)):
            continue
        lower = url.lower()
        if any(word in lower for word in EMBED_WORDS) or "/embed" in lower:
            findings.append(Finding("text-url", url, str(path), "regex"))
    return findings


def extract_from_json_obj(obj: Any, source: str, include_media: bool, key_path: str = "$") -> list[Finding]:
    findings: list[Finding] = []
    if isinstance(obj, dict):
        urlish: list[tuple[str, str]] = []
        label = ""
        for key, value in obj.items():
            path = f"{key_path}.{key}"
            key_l = str(key).lower()
            if key_l in {"name", "title", "label", "server", "host"} and isinstance(value, str):
                label = value[:120]
            if isinstance(value, str):
                normalized = normalize_url(value)
                if normalized and (URL_RE.search(value) or PATH_RE.search(value)):
                    urlish.append((path, normalized))
            findings.extend(extract_from_json_obj(value, source, include_media, path))

        keys = {str(key).lower() for key in obj.keys()}
        context = f"{key_path} {' '.join(keys)}".lower()
        is_server_link_record = bool({"host", "link"} <= keys or {"host_id", "link"} <= keys)
        if any(word in context for word in JSON_CONTEXT_WORDS) or is_server_link_record:
            for path, url in urlish:
                if not include_media and is_media_url(url):
                    continue
                kind = "server-link" if is_server_link_record else "json-field"
                findings.append(Finding(kind, url, source, path, label=label or str(obj.get("host", ""))[:120]))
        else:
            for path, url in urlish:
                lower = f"{path} {url}".lower()
                if "/embed" not in lower:
                    continue
                if not include_media and is_media_url(url):
                    continue
                findings.append(Finding("json-field", url, source, path, label=label))
    elif isinstance(obj, list):
        for index, item in enumerate(obj):
            findings.extend(extract_from_json_obj(item, source, include_media, f"{key_path}[{index}]"))
    elif isinstance(obj, str) and looks_embed_related(obj, key_path):
        for match in URL_RE.finditer(obj):
            url = normalize_url(match.group(0))
            if url and (include_media or not is_media_url(url)):
                findings.append(Finding("json-string", url, source, key_path))
    return findings


def extract_from_json_lines(path: Path, text: str, include_media: bool) -> list[Finding]:
    findings: list[Finding] = []
    for line_no, line in enumerate(text.splitlines(), 1):
        stripped = line.strip()
        if not stripped:
            continue
        try:
            obj = json.loads(stripped)
        except json.JSONDecodeError:
            findings.extend(extract_urls_from_text(path, stripped, include_media))
            continue
        findings.extend(extract_from_json_obj(obj, f"{path}:{line_no}", include_media))
    return findings


def extract_from_file(path: Path, include_media: bool) -> list[Finding]:
    text = read_text(path)
    suffix = path.suffix.lower()
    if suffix == ".html":
        return extract_from_html(path, text, include_media)
    if suffix == ".json":
        try:
            return extract_from_json_obj(json.loads(text), str(path), include_media)
        except json.JSONDecodeError:
            return extract_urls_from_text(path, text, include_media)
    if suffix == ".jsonl":
        return extract_from_json_lines(path, text, include_media)
    return extract_urls_from_text(path, text, include_media)


def find_server_lists(obj: Any) -> list[dict[str, Any]]:
    lists: list[dict[str, Any]] = []
    if isinstance(obj, dict):
        servers = obj.get("servers")
        if isinstance(servers, list) and all(isinstance(item, dict) for item in servers):
            if any("file_name" in item or "file_size" in item or "audio_language" in item for item in servers):
                info = obj.get("info") if isinstance(obj.get("info"), dict) else {}
                lists.append({"servers": servers, "info": info})
        for value in obj.values():
            lists.extend(find_server_lists(value))
    elif isinstance(obj, list):
        for item in obj:
            lists.extend(find_server_lists(item))
    return lists


def server_entries_from_api(servers: list[dict[str, Any]]) -> list[ServerEntry]:
    grouped: dict[str, ServerEntry] = {}
    for item in servers:
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        entry = grouped.setdefault(name, ServerEntry(name=name, options=[]))
        option = ServerOption(
            index=len(entry.options) + 1,
            key=str(item.get("key") or "").strip(),
            title=str(item.get("file_name") or "").strip(),
            file_size=str(item.get("file_size") or "").strip(),
            quality=str(item.get("quality") or "").strip(),
            audio_type=str(item.get("audio_type") or "").strip(),
            audio_language=str(item.get("audio_language") or "").strip(),
        )
        if option.key:
            option.api_url = f"https://primesrc.me/api/v1/l?key={quote(option.key, safe='')}"
        entry.options.append(option)
    return list(grouped.values())


def merge_server_entries(target: dict[str, ServerEntry], entries: list[ServerEntry]) -> None:
    for entry in entries:
        if not entry.name:
            continue
        existing = target.setdefault(entry.name, ServerEntry(name=entry.name, options=[], selected=entry.selected))
        existing.selected = existing.selected or entry.selected
        for option in entry.options:
            option.index = len(existing.options) + 1
            existing.options.append(option)


def extract_link_map_from_text(text: str) -> dict[str, dict[str, str]]:
    link_map: dict[str, dict[str, str]] = {}
    endpoint_re = re.compile(r"https://primesrc\.me/api/v1/l\?key=([A-Za-z0-9_-]+)")
    json_re = re.compile(r"\{[^{}]*\"link\"\s*:\s*\"([^\"]+)\"[^{}]*\}", re.S)

    for endpoint_match in endpoint_re.finditer(text):
        key = endpoint_match.group(1)
        window = text[endpoint_match.end() : endpoint_match.end() + 1200]
        json_match = json_re.search(window)
        if not json_match:
            continue
        try:
            obj = json.loads(json_match.group(0))
        except json.JSONDecodeError:
            continue
        link_map[key] = {
            "link": str(obj.get("link") or ""),
            "host": str(obj.get("host") or ""),
            "host_id": str(obj.get("host_id") or ""),
        }
    return link_map


def load_link_logs(paths: list[Path]) -> dict[str, dict[str, str]]:
    link_map: dict[str, dict[str, str]] = {}
    for path in paths:
        if not path.exists():
            print(f"Link log not found: {path}", file=sys.stderr)
            continue
        files = [path] if path.is_file() else sorted(path.rglob("*.txt"))
        for file_path in files:
            link_map.update(extract_link_map_from_text(read_text(file_path)))
    return link_map


def infer_main_url_from_capture(capture_dir: Path) -> str:
    for name in ("referrer_chain.json", "full_capture.jsonl", "api_endpoints.json"):
        path = capture_dir / name
        if not path.exists():
            continue
        text = read_text(path).replace("\\u0026", "&")
        match = MAIN_URL_RE.search(text)
        if match:
            return match.group(0).rstrip(",)")
    return ""


def build_server_api_url(main_url: str) -> str:
    parsed = urlparse(main_url)
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    if parsed.path.startswith("/embed/movie"):
        params.setdefault("type", "movie")
    elif parsed.path.startswith("/embed/tv"):
        params.setdefault("type", "tv")
    elif "type" not in params:
        raise ValueError(f"Cannot infer type from PrimeSrc URL path: {parsed.path}")

    base = f"{parsed.scheme or 'https'}://{parsed.netloc or 'primesrc.me'}"
    return f"{base}/api/v1/s?{urlencode(params)}"


def build_main_url_from_target(target: str | None, media_type: str) -> str:
    value = (target or DEFAULT_MAIN_URL).strip()
    if TMDB_ID_RE.fullmatch(value):
        return f"https://primesrc.me/embed/{media_type}?tmdb={value}"
    if value.startswith("primesrc.me/"):
        return "https://" + value
    if value.startswith("/embed/"):
        return "https://primesrc.me" + value
    if value.startswith("http://") or value.startswith("https://"):
        return value
    raise ValueError(
        "Target must be a TMDB id or PrimeSrc embed URL, "
        "for example 218 or https://primesrc.me/embed/movie?tmdb=218"
    )


def split_target_values(values: list[str] | None) -> list[str]:
    targets: list[str] = []
    for value in values or []:
        for part in re.split(r"[\r\n,]+", value):
            part = part.strip()
            if part:
                targets.append(part)
    return targets


def read_targets_from_file(path: Path) -> list[str]:
    if not path.exists():
        raise FileNotFoundError(f"URL file not found: {path}")
    return split_target_values([read_text(path)])


def build_main_urls_from_args(args: argparse.Namespace) -> tuple[list[str], bool]:
    raw_targets: list[str] = []
    raw_targets.extend(split_target_values(args.main_url_override))
    raw_targets.extend(split_target_values(args.tmdb))
    raw_targets.extend(split_target_values(args.targets))
    if args.url_file:
        for url_file in args.url_file:
            raw_targets.extend(read_targets_from_file(url_file))
    elif not raw_targets and DEFAULT_URL_FILE.exists():
        raw_targets.extend(read_targets_from_file(DEFAULT_URL_FILE))

    explicit_target = bool(raw_targets)
    if not raw_targets:
        raw_targets = [DEFAULT_MAIN_URL]

    urls: list[str] = []
    seen: set[str] = set()
    for target in raw_targets:
        url = build_main_url_from_target(target, args.type)
        if url in seen:
            continue
        seen.add(url)
        urls.append(url)
    return urls, explicit_target


def media_identity_from_main_url(main_url: str) -> dict[str, str]:
    parsed = urlparse(main_url)
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    media_type = ""
    if parsed.path.startswith("/embed/movie"):
        media_type = "movie"
    elif parsed.path.startswith("/embed/tv"):
        media_type = "tv"
    return {
        "type": params.get("type") or media_type,
        "tmdb": params.get("tmdb", ""),
        "imdb": params.get("imdb") or params.get("imdb_id") or "",
    }


def fetch_json_url(url: str, referer: str) -> Any:
    req = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json",
            "Referer": referer,
        },
    )
    with urlopen(req, timeout=20) as response:
        return json.loads(response.read().decode(response.headers.get_content_charset() or "utf-8", errors="replace"))


def fetch_server_list_from_main_url(main_url: str) -> dict[str, Any]:
    return fetch_json_url(build_server_api_url(main_url), main_url)


def fetch_link_for_key(key: str, main_url: str) -> dict[str, str]:
    api_url = f"https://primesrc.me/api/v1/l?key={quote(key, safe='')}"
    obj = fetch_json_url(api_url, main_url)
    return {
        "key": key,
        "api_url": api_url,
        "link": str(obj.get("link") or ""),
        "host": str(obj.get("host") or ""),
        "host_id": str(obj.get("host_id") or ""),
    }


def key_from_link_api_url(url: str) -> str:
    parsed = urlparse(url)
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    key = params.get("key", "").strip()
    if not key:
        raise ValueError(f"No key= parameter found in link API URL: {url}")
    return key


def fetch_link_api_records(keys: list[str], api_urls: list[str], main_url: str) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    all_keys = list(keys)
    for api_url in api_urls:
        all_keys.append(key_from_link_api_url(api_url))

    for key in all_keys:
        try:
            record = fetch_link_for_key(key, main_url)
        except Exception as exc:
            record = {
                "key": key,
                "api_url": f"https://primesrc.me/api/v1/l?key={quote(key, safe='')}",
                "link": "",
                "host": "",
                "host_id": "",
                "error": f"{type(exc).__name__}: {exc}",
            }
        records.append(record)
    return records


def find_link_objects(obj: Any, source: str) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    if isinstance(obj, dict):
        if "link" in obj and isinstance(obj.get("link"), str):
            records.append(
                {
                    "key": str(obj.get("key") or ""),
                    "api_url": source,
                    "link": str(obj.get("link") or ""),
                    "host": str(obj.get("host") or ""),
                    "host_id": str(obj.get("host_id") or ""),
                }
            )

        for key, value in obj.items():
            child_source = source
            if key == "url" and isinstance(value, str) and "/api/v1/l?" in value:
                child_source = value
            records.extend(find_link_objects(value, child_source))
    elif isinstance(obj, list):
        for item in obj:
            records.extend(find_link_objects(item, source))
    elif isinstance(obj, str) and '"link"' in obj:
        try:
            nested = json.loads(obj)
        except json.JSONDecodeError:
            for match in re.finditer(r"\{[^{}]*\"link\"\s*:\s*\"[^\"]+\"[^{}]*\}", obj, re.S):
                try:
                    records.extend(find_link_objects(json.loads(match.group(0)), source))
                except json.JSONDecodeError:
                    pass
        else:
            records.extend(find_link_objects(nested, source))
    return records


def extract_link_response_records(paths: list[Path]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for path in paths:
        if not path.exists():
            records.append({"key": "", "api_url": str(path), "link": "", "host": "", "host_id": "", "error": "File not found"})
            continue
        files = [path] if path.is_file() else sorted(path.rglob("*"))
        for file_path in files:
            if not file_path.is_file():
                continue
            text = read_text(file_path)
            try:
                obj = json.loads(text)
            except json.JSONDecodeError:
                for match in re.finditer(r"\{[^{}]*\"link\"\s*:\s*\"[^\"]+\"[^{}]*\}", text, re.S):
                    try:
                        records.extend(find_link_objects(json.loads(match.group(0)), str(file_path)))
                    except json.JSONDecodeError:
                        pass
            else:
                records.extend(find_link_objects(obj, str(file_path)))
    return records


def print_link_api_records(records: list[dict[str, str]], links_only: bool = False) -> None:
    for record in records:
        if links_only:
            if record.get("link"):
                print(record["link"])
            elif record.get("error"):
                print(f"# {record['api_url']} -> {record['error']}")
            continue

        print(f"Key: {record['key']}")
        print(f"API: {record['api_url']}")
        if record.get("link"):
            print(f"Link: {record['link']}")
            if record.get("host"):
                print(f"Host: {record['host']}")
            if record.get("host_id"):
                print(f"Host ID: {record['host_id']}")
        else:
            print(f"Error: {record.get('error', 'No link in response')}")
        print()


def apply_link_map(servers: list[ServerEntry], link_map: dict[str, dict[str, str]]) -> None:
    for server in servers:
        for option in server.options:
            if not option.key or option.key not in link_map:
                continue
            data = link_map[option.key]
            option.link = data.get("link", "")
            option.host = data.get("host", "")
            option.host_id = data.get("host_id", "")


def fetch_missing_links(servers: list[ServerEntry], main_url: str) -> None:
    for server in servers:
        for option in server.options:
            if not option.key or option.link:
                continue
            try:
                data = fetch_link_for_key(option.key, main_url)
            except Exception as exc:
                option.link_error = f"{type(exc).__name__}: {exc}"
                continue
            option.link = data.get("link", "")
            option.host = data.get("host", "")
            option.host_id = data.get("host_id", "")


def extract_server_list(
    capture_dir: Path,
    main_url: str = DEFAULT_MAIN_URL,
    link_logs: list[Path] | None = None,
    live_servers: bool = False,
    scan_capture: bool = True,
    fetch_links: bool = False,
) -> dict[str, Any]:
    grouped: dict[str, ServerEntry] = {}
    sources: list[str] = []
    title = ""

    if live_servers:
        try:
            obj = fetch_server_list_from_main_url(main_url)
        except Exception as exc:
            sources.append(f"live server API failed: {type(exc).__name__}: {exc}")
        else:
            for result in find_server_lists(obj):
                entries = server_entries_from_api(result["servers"])
                if entries:
                    merge_server_entries(grouped, entries)
                    sources.append(build_server_api_url(main_url))
                    info = result.get("info") or {}
                    title = title or str(info.get("title") or "")

    if scan_capture and capture_dir.exists():
        likely_files = [
            capture_dir / "xhr_responses" / "primesrc.me_s.json",
            capture_dir / "html_pages" / "primesrc.me_movie.html",
            capture_dir / "html_pages" / "primesrc.me_tv.html",
        ]
        files = [path for path in likely_files if path.exists()]
        if not files:
            files = iter_capture_files(capture_dir)

        for path in files:
            text = read_text(path)
            if path.suffix.lower() == ".json":
                try:
                    obj = json.loads(text)
                except json.JSONDecodeError:
                    continue
                for result in find_server_lists(obj):
                    entries = server_entries_from_api(result["servers"])
                    if entries:
                        merge_server_entries(grouped, entries)
                        sources.append(str(path))
                        info = result.get("info") or {}
                        title = title or str(info.get("title") or "")
                continue

            if path.suffix.lower() == ".html" and "server-menu-item" in text:
                parser = ServerMenuHTMLParser()
                parser.feed(text)
                if parser.servers:
                    merge_server_entries(grouped, parser.servers)
                    sources.append(str(path))

    servers = list(grouped.values())
    if link_logs:
        apply_link_map(servers, load_link_logs(link_logs))
    if fetch_links:
        fetch_missing_links(servers, main_url)

    return {
        "main_url": main_url,
        "server_api_url": build_server_api_url(main_url),
        "title": title,
        "total_servers": len(servers),
        "total_options": sum(len(server.options) for server in servers),
        "total_links": sum(1 for server in servers for option in server.options if option.link),
        "sources": sorted(set(sources)),
        "servers": [
            {
                "name": server.name,
                "selected": server.selected,
                "option_count": len(server.options),
                "options": [asdict(option) for option in server.options],
            }
            for server in servers
        ],
    }


def print_server_list(report: dict[str, Any]) -> None:
    print(f"Main URL: {report['main_url']}")
    print(f"Server API: {report['server_api_url']}")
    if report.get("title"):
        print(f"Title: {report['title']}")
    print(f"Servers: {report['total_servers']}")
    print(f"Options: {report['total_options']}")
    print(f"Resolved links: {report.get('total_links', 0)}")
    print()

    for server in report["servers"]:
        selected = " selected" if server.get("selected") else ""
        print(f"{server['name']} ({server['option_count']} option(s)){selected}")
        for option in server["options"]:
            meta = []
            if option.get("file_size"):
                meta.append(option["file_size"])
            if option.get("quality"):
                meta.append(option["quality"])
            if option.get("audio_language"):
                meta.append(option["audio_language"])
            suffix = f" [{' | '.join(meta)}]" if meta else ""
            title = option.get("title") or "(no title)"
            key = f" key={option['key']}" if option.get("key") else ""
            print(f"  {option['index']}. {title}{suffix}{key}")
            if option.get("api_url"):
                print(f"     API: {option['api_url']}")
            if option.get("link"):
                host = f" ({option['host']})" if option.get("host") else ""
                print(f"     Link: {option['link']}{host}")
            elif option.get("link_error"):
                print(f"     Link error: {option['link_error']}")
        print()


def safe_cell(value: Any) -> str:
    text = "" if value is None else str(value)
    return escape(text)


def link_cell(value: Any) -> str:
    text = "" if value is None else str(value)
    if not text:
        return ""
    href = escape(text, quote=True)
    label = escape(text)
    return f'<a href="{href}" target="_blank" rel="noreferrer">{label}</a>'


def render_table(headers: list[str], rows: list[list[str]]) -> str:
    head = "".join(f"<th>{escape(header)}</th>" for header in headers)
    if not rows:
        body = f'<tr><td colspan="{len(headers)}" class="empty">No rows</td></tr>'
    else:
        body = "\n".join(
            "<tr>"
            + "".join(
                f'<td data-label="{escape(headers[index], quote=True)}">{cell}</td>'
                for index, cell in enumerate(row)
            )
            + "</tr>"
            for row in rows
        )
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def movie_unique_key_from_url(main_url: str) -> str:
    parsed = urlparse(main_url)
    params = dict(parse_qsl(parsed.query, keep_blank_values=True))
    imdb_id = (params.get("imdb") or params.get("imdb_id") or "").strip().lower()
    tmdb_id = (params.get("tmdb") or params.get("tmdb_id") or "").strip().lower()
    if imdb_id:
        return f"imdb:{imdb_id}"
    if tmdb_id:
        return f"tmdb:{tmdb_id}"
    return f"url:{main_url.strip().lower()}"


def build_result_rows_from_reports(reports: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for report in reports:
        movie_name = str(report.get("title") or "")
        main_url = str(report.get("main_url") or "")
        server_options = [
            (server, option)
            for server in report.get("servers") or []
            for option in server.get("options") or []
        ]

        if not server_options:
            rows.append(
                {
                    "serial_no": "",
                    "movie_name": movie_name,
                    "server_name": "",
                    "api_full_url_key": "",
                    "key": "",
                    "primesrc_main_url_tmdb": main_url,
                }
            )
            continue

        for server, option in server_options:
            rows.append(
                {
                    "serial_no": "",
                    "movie_name": movie_name,
                    "server_name": str(server.get("name") or ""),
                    "api_full_url_key": str(option.get("api_url") or ""),
                    "key": str(option.get("key") or ""),
                    "primesrc_main_url_tmdb": main_url,
                }
            )
    return rows


def read_existing_result_rows(html_path: Path) -> list[dict[str, str]]:
    if not html_path.exists():
        return []
    parser = ResultTableHTMLParser()
    parser.feed(read_text(html_path))
    return parser.rows


def merge_unique_movie_rows(existing_rows: list[dict[str, str]], new_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    merged: list[dict[str, str]] = []
    seen_movies: set[str] = set()
    seen_rows: set[tuple[str, ...]] = set()

    def add_movie_rows(rows: list[dict[str, str]], allow_existing_movie: bool) -> None:
        grouped: dict[str, list[dict[str, str]]] = {}
        order: list[str] = []
        for row in rows:
            movie_key = movie_unique_key_from_url(row.get("primesrc_main_url_tmdb", ""))
            if movie_key not in grouped:
                grouped[movie_key] = []
                order.append(movie_key)
            grouped[movie_key].append({header: str(row.get(header, "")) for header in RESULT_HEADERS})

        for movie_key in order:
            if movie_key in seen_movies and not allow_existing_movie:
                continue
            if movie_key in seen_movies and allow_existing_movie:
                continue
            for row in grouped[movie_key]:
                row_key = tuple(row.get(header, "") for header in RESULT_HEADERS[1:])
                if row_key in seen_rows:
                    continue
                merged.append(row)
                seen_rows.add(row_key)
            seen_movies.add(movie_key)

    add_movie_rows(existing_rows, allow_existing_movie=True)
    add_movie_rows(new_rows, allow_existing_movie=False)
    renumber_result_rows(merged)
    return merged


def renumber_result_rows(rows: list[dict[str, str]]) -> None:
    serial_by_movie: dict[str, int] = {}
    for row in rows:
        movie_key = movie_unique_key_from_url(row.get("primesrc_main_url_tmdb", ""))
        if movie_key not in serial_by_movie:
            serial_by_movie[movie_key] = len(serial_by_movie) + 1
        row["serial_no"] = str(serial_by_movie[movie_key])


def result_rows_to_html_cells(rows: list[dict[str, str]]) -> list[list[str]]:
    html_rows: list[list[str]] = []
    for row in rows:
        html_rows.append(
            [
                safe_cell(row.get("serial_no", "")),
                safe_cell(row.get("movie_name", "")),
                safe_cell(row.get("server_name", "")),
                link_cell(row.get("api_full_url_key", "")),
                safe_cell(row.get("key", "")),
                link_cell(row.get("primesrc_main_url_tmdb", "")),
            ]
        )
    return html_rows


def render_result_rows_html(rows: list[dict[str, str]]) -> str:
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    unique_movies = {movie_unique_key_from_url(row.get("primesrc_main_url_tmdb", "")) for row in rows}
    results_table = render_table(RESULT_HEADERS, result_rows_to_html_cells(rows))

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>PrimeSrc Results</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f6f7f9;
      --panel: #ffffff;
      --ink: #20242a;
      --muted: #626b78;
      --line: #d8dde5;
      --accent: #1f6feb;
      --header: #eef3fb;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: "Segoe UI", Arial, sans-serif;
      font-size: 14px;
      line-height: 1.45;
    }}
    header {{
      padding: 24px clamp(14px, 4vw, 28px) 16px;
      background: var(--panel);
      border-bottom: 1px solid var(--line);
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 26px;
      letter-spacing: 0;
    }}
    .meta {{
      color: var(--muted);
      display: flex;
      flex-wrap: wrap;
      gap: 10px 18px;
    }}
    main {{
      padding: 20px clamp(12px, 4vw, 28px) 36px;
    }}
    section {{
      margin: 0 0 24px;
    }}
    h2 {{
      margin: 0 0 10px;
      font-size: 18px;
      letter-spacing: 0;
    }}
    .table-wrap {{
      overflow-x: auto;
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      max-width: 100%;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      min-width: 980px;
    }}
    th, td {{
      padding: 9px 10px;
      border-bottom: 1px solid var(--line);
      border-right: 1px solid var(--line);
      text-align: left;
      vertical-align: top;
      white-space: nowrap;
    }}
    th:first-child, td:first-child {{
      width: 88px;
      text-align: center;
    }}
    th:last-child, td:last-child {{ border-right: 0; }}
    tr:last-child td {{ border-bottom: 0; }}
    th {{
      position: sticky;
      top: 0;
      background: var(--header);
      font-weight: 650;
      color: #273141;
    }}
    td {{
      max-width: 520px;
      overflow: hidden;
      text-overflow: ellipsis;
    }}
    a {{
      color: var(--accent);
      text-decoration: none;
    }}
    a:hover {{ text-decoration: underline; }}
    .empty {{
      color: var(--muted);
      text-align: center;
    }}
    @media (max-width: 760px) {{
      body {{
        font-size: 13px;
      }}
      h1 {{
        font-size: 22px;
      }}
      .meta {{
        display: block;
      }}
      .meta span {{
        display: block;
        margin-top: 4px;
      }}
      .table-wrap {{
        overflow: visible;
        border: 0;
        background: transparent;
      }}
      table, thead, tbody, tr, td {{
        display: block;
        width: 100%;
        min-width: 0;
      }}
      table {{
        border-collapse: separate;
        border-spacing: 0 10px;
      }}
      thead {{
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
      }}
      tr {{
        background: var(--panel);
        border: 1px solid var(--line);
        border-radius: 8px;
        overflow: hidden;
      }}
      th:first-child, td:first-child {{
        width: 100%;
        text-align: left;
      }}
      td {{
        display: grid;
        grid-template-columns: minmax(110px, 34%) minmax(0, 1fr);
        gap: 10px;
        max-width: none;
        white-space: normal;
        overflow-wrap: anywhere;
        border-right: 0;
      }}
      td::before {{
        content: attr(data-label);
        color: var(--muted);
        font-weight: 650;
      }}
      td:last-child {{
        border-bottom: 0;
      }}
      a {{
        overflow-wrap: anywhere;
      }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>PrimeSrc Results</h1>
    <div class="meta">
      <span>Generated: {safe_cell(generated_at)}</span>
      <span>Unique movies: {len(unique_movies)}</span>
      <span>Saved rows: {len(rows)}</span>
    </div>
  </header>
  <main>
    <section>
      <h2>Results</h2>
      <div class="table-wrap">{results_table}</div>
    </section>
  </main>
</body>
</html>
"""


def excel_column_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def write_result_rows_xlsx(rows: list[dict[str, str]], output_path: Path) -> None:
    table_rows = [RESULT_HEADERS] + [[row.get(header, "") for header in RESULT_HEADERS] for row in rows]
    sheet_rows: list[str] = []
    for row_index, row in enumerate(table_rows, 1):
        cells: list[str] = []
        for column_index, value in enumerate(row, 1):
            ref = f"{excel_column_name(column_index)}{row_index}"
            cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>')
        sheet_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')

    sheet_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <cols>
    <col min="1" max="1" width="10" customWidth="1"/>
    <col min="2" max="2" width="38" customWidth="1"/>
    <col min="3" max="3" width="18" customWidth="1"/>
    <col min="4" max="4" width="42" customWidth="1"/>
    <col min="5" max="5" width="16" customWidth="1"/>
    <col min="6" max="6" width="46" customWidth="1"/>
  </cols>
  <sheetData>
    {''.join(sheet_rows)}
  </sheetData>
</worksheet>"""
    workbook_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="PrimeSrc Results" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>"""
    content_types_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>"""
    root_rels_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""
    workbook_rels_xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>"""

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types_xml)
        archive.writestr("_rels/.rels", root_rels_xml)
        archive.writestr("xl/workbook.xml", workbook_xml)
        archive.writestr("xl/_rels/workbook.xml.rels", workbook_rels_xml)
        archive.writestr("xl/worksheets/sheet1.xml", sheet_xml)


def write_server_reports_outputs(reports: list[dict[str, Any]], html_path: Path, xlsx_path: Path | None = None) -> list[dict[str, str]]:
    existing_rows = read_existing_result_rows(html_path)
    new_rows = build_result_rows_from_reports(reports)
    merged_rows = merge_unique_movie_rows(existing_rows, new_rows)
    html_path.write_text(render_result_rows_html(merged_rows), encoding="utf-8")
    if xlsx_path:
        write_result_rows_xlsx(merged_rows, xlsx_path)
    return merged_rows


def fetch_live_url(url: str) -> str:
    req = Request(
        url,
        headers={
            "User-Agent": "capture-iframe-auditor/1.0 (+authorized-analysis)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(req, timeout=20) as response:
        content_type = response.headers.get_content_charset() or "utf-8"
        return response.read().decode(content_type, errors="replace")


def dedupe_findings(findings: list[Finding]) -> list[Finding]:
    seen: set[tuple[str, str, str]] = set()
    unique: list[Finding] = []
    for item in findings:
        key = (item.kind, item.url, item.source)
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return unique


def build_report(findings: list[Finding], files_scanned: int) -> dict[str, Any]:
    domains: dict[str, int] = {}
    for item in findings:
        host = urlparse(item.url).netloc.lower()
        if host:
            domains[host] = domains.get(host, 0) + 1

    return {
        "files_scanned": files_scanned,
        "total_findings": len(findings),
        "domains": dict(sorted(domains.items(), key=lambda pair: (-pair[1], pair[0]))),
        "findings": [asdict(item) for item in findings],
    }


def print_report(report: dict[str, Any], limit: int) -> None:
    print(f"Files scanned: {report['files_scanned']}")
    print(f"Findings: {report['total_findings']}")
    print("\nDomains:")
    for host, count in list(report["domains"].items())[:limit]:
        print(f"  {count:4d}  {host}")

    print("\nIframe/embed candidates:")
    for item in report["findings"][:limit]:
        label = f" [{item['label']}]" if item.get("label") else ""
        print(f"  - {item['url']}{label}")
        print(f"    kind={item['kind']} detail={item['detail']} source={item['source']}")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract the clean server menu list for any PrimeSrc TMDB id or URL.")
    parser.add_argument(
        "targets",
        nargs="*",
        help=(
            "One or more TMDB ids or PrimeSrc embed URLs. Comma-separated values also work, "
            "for example 218 https://primesrc.me/embed/movie?tmdb=296"
        ),
    )
    parser.add_argument("--main-url", dest="main_url_override", action="append", help="PrimeSrc embed URL to analyze. Can be repeated.")
    parser.add_argument("--tmdb", action="append", help="TMDB id to analyze. Can be repeated.")
    parser.add_argument(
        "--url-file",
        type=Path,
        action="append",
        help=f"Text file of PrimeSrc URLs or TMDB ids. Default is used when present: {DEFAULT_URL_FILE}",
    )
    parser.add_argument("--type", choices=("movie", "tv"), default="movie", help="Media type when using a bare TMDB id.")
    parser.add_argument("--capture-dir", type=Path, default=DEFAULT_CAPTURE_DIR, help="Capture folder to scan.")
    parser.add_argument("--servers-only", action="store_true", help="Print only the server menu list.")
    parser.add_argument("--embeds", action="store_true", help="Run the older broad iframe/embed URL scan.")
    parser.add_argument(
        "--live-servers",
        action="store_true",
        help="Fetch the public /api/v1/s server list for the supplied PrimeSrc URL.",
    )
    parser.add_argument(
        "--offline-capture",
        action="store_true",
        help="Read server data from the saved capture instead of the live /api/v1/s endpoint.",
    )
    parser.add_argument("--url", help="Optional live URL to fetch, only for authorized analysis.")
    parser.add_argument(
        "--use-default-url",
        action="store_true",
        help=f"Use the hardcoded default live URL: {DEFAULT_MAIN_URL}",
    )
    parser.add_argument("--i-am-authorized", action="store_true", help="Required when using --url.")
    parser.add_argument(
        "--link-log",
        type=Path,
        action="append",
        default=[],
        help="Text file or folder containing pasted /api/v1/l?key=... JSON responses.",
    )
    parser.add_argument(
        "--key",
        action="append",
        default=[],
        help="Resolve one PrimeSrc /api/v1/l key and print its response link. Can be repeated.",
    )
    parser.add_argument(
        "--link-api",
        action="append",
        default=[],
        help="Resolve a full PrimeSrc /api/v1/l?key=... URL and print its response link. Can be repeated.",
    )
    parser.add_argument(
        "--response-file",
        type=Path,
        action="append",
        default=[],
        help="Read saved JSON/text response files and print only their link fields.",
    )
    parser.add_argument("--links-only", action="store_true", help="With --key/--link-api, print only the extracted link URL.")
    parser.add_argument(
        "--fetch-links",
        action="store_true",
        help="Try to resolve every server key through the live /api/v1/l endpoint. Requires --i-am-authorized.",
    )
    parser.add_argument("--include-media", action="store_true", help="Include direct media playlists/segments/files.")
    parser.add_argument("--output", type=Path, help="Write full JSON report to this file.")
    parser.add_argument(
        "--html-output",
        type=Path,
        default=DEFAULT_HTML_OUTPUT,
        help=f"Write the server results to an HTML relational table report. Default: {DEFAULT_HTML_OUTPUT}",
    )
    parser.add_argument(
        "--xlsx-output",
        type=Path,
        default=DEFAULT_XLSX_OUTPUT,
        help=f"Write the same saved rows to an XLSX report. Default: {DEFAULT_XLSX_OUTPUT}",
    )
    parser.add_argument("--no-html", action="store_true", help="Do not write the default HTML server report.")
    parser.add_argument("--limit", type=int, default=100, help="Number of console rows to print.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    try:
        main_urls, explicit_target = build_main_urls_from_args(args)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    main_url = main_urls[0]

    if args.key or args.link_api or args.response_file:
        records = []
        if args.response_file:
            records.extend(extract_link_response_records(args.response_file))
        if args.key or args.link_api:
            records.extend(fetch_link_api_records(args.key, args.link_api, main_url))
        print_link_api_records(records, links_only=args.links_only)
        if args.output:
            args.output.write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"Wrote JSON report: {args.output}")
        return 0

    if args.servers_only or not args.embeds:
        if args.fetch_links and not args.i_am_authorized:
            print("Refusing live link fetch without --i-am-authorized.", file=sys.stderr)
            return 2
        live_servers = not args.offline_capture
        scan_capture = args.offline_capture
        if scan_capture and not explicit_target:
            main_url = infer_main_url_from_capture(args.capture_dir) or main_url
            main_urls = [main_url]
        if scan_capture and not args.capture_dir.exists():
            print(f"Capture folder not found: {args.capture_dir}", file=sys.stderr)
            return 1
        server_reports: list[dict[str, Any]] = []
        for index, target_url in enumerate(main_urls, 1):
            if len(main_urls) > 1:
                print(f"=== Target {index}/{len(main_urls)} ===")
            server_report = extract_server_list(
                args.capture_dir,
                main_url=target_url,
                link_logs=args.link_log,
                live_servers=live_servers,
                scan_capture=scan_capture,
                fetch_links=args.fetch_links,
            )
            server_reports.append(server_report)
            print_server_list(server_report)
        if args.output:
            json_payload: Any = server_reports[0] if len(server_reports) == 1 else server_reports
            args.output.write_text(json.dumps(json_payload, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"Wrote JSON report: {args.output}")
        if args.html_output and not args.no_html:
            saved_rows = write_server_reports_outputs(server_reports, args.html_output, args.xlsx_output)
            print(f"Wrote HTML report: {args.html_output}")
            if args.xlsx_output:
                print(f"Wrote XLSX report: {args.xlsx_output}")
            print(f"Saved unique movies: {len({movie_unique_key_from_url(row.get('primesrc_main_url_tmdb', '')) for row in saved_rows})}")
        return 0

    findings: list[Finding] = []
    files_scanned = 0

    if args.capture_dir.exists():
        files = iter_capture_files(args.capture_dir)
        files_scanned += len(files)
        for path in files:
            findings.extend(extract_from_file(path, args.include_media))
    else:
        print(f"Capture folder not found: {args.capture_dir}", file=sys.stderr)

    live_url = main_url if args.use_default_url else args.url
    if live_url:
        if not args.i_am_authorized:
            print("Refusing live fetch without --i-am-authorized.", file=sys.stderr)
            return 2
        html = fetch_live_url(live_url)
        parser = EmbedHTMLParser(live_url, live_url, args.include_media)
        parser.feed(html)
        findings.extend(parser.findings)
        findings.extend(extract_urls_from_text(Path(live_url), html, args.include_media))
        files_scanned += 1

    report = build_report(dedupe_findings(findings), files_scanned)
    print_report(report, max(1, args.limit))

    if args.output:
        args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nWrote JSON report: {args.output}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
