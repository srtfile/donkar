import argparse
import asyncio
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import warnings
warnings.filterwarnings("ignore", category=ResourceWarning)

# ──────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────
API_URL_LIST   = os.path.join(os.path.dirname(__file__), "api_url_list.txt")
USER_DATA_DIR  = r"C:\Users\AC\AppData\Local\Google\Chrome\User Data"
PROFILE_DIR    = "Profile 2"
CHROME_EXE     = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_EXE_ALT = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
DEBUG_PORT     = 9222
PROFILE_CACHE_ROOT = os.path.join(tempfile.gettempdir(), "primesrc_profile_cache")

CACHE_NAMES = {
    "AutofillAiModelCache", "Cache", "CacheStorage", "Code Cache",
    "DawnGraphiteCache", "DawnWebGPUCache", "GPUCache", "GrShaderCache",
    "LOCK", "LOG", "LOG.old", "optimization_guide_hint_cache_store",
    "ShaderCache", "SingletonCookie", "SingletonLock", "SingletonSocket",
}

# ──────────────────────────────────────────────
# CHROME MANAGEMENT
# ──────────────────────────────────────────────

def kill_chrome():
    subprocess.run(["taskkill", "/F", "/IM", "chrome.exe"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    print("   Killed existing Chrome processes")

def is_chrome_running():
    try:
        result = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq chrome.exe"],
            capture_output=True, text=True, check=False,
        )
        return "chrome.exe" in result.stdout.lower()
    except Exception:
        return False

def remove_profile_lock():
    lock_files = [
        os.path.join(USER_DATA_DIR, f)
        for f in ("SingletonLock", "SingletonCookie", "SingletonSocket")
    ] + [
        os.path.join(USER_DATA_DIR, PROFILE_DIR, f)
        for f in ("SingletonLock", "SingletonCookie", "SingletonSocket")
    ]
    for lf in lock_files:
        if os.path.exists(lf):
            try:
                os.remove(lf)
            except Exception:
                pass

def get_chrome_exe():
    for exe in (CHROME_EXE, CHROME_EXE_ALT):
        if os.path.exists(exe):
            return exe
    raise FileNotFoundError("Chrome not found at default locations.")

def remove_chrome_locks(user_data_dir):
    for rel in (
        "SingletonLock", "SingletonCookie", "SingletonSocket",
        os.path.join(PROFILE_DIR, "SingletonLock"),
        os.path.join(PROFILE_DIR, "SingletonCookie"),
        os.path.join(PROFILE_DIR, "SingletonSocket"),
        os.path.join(PROFILE_DIR, "LOCK"),
    ):
        p = os.path.join(user_data_dir, rel)
        if os.path.exists(p):
            try:
                os.remove(p)
            except Exception:
                pass

def copy_profile_for_automation(refresh=False):
    src = os.path.join(USER_DATA_DIR, PROFILE_DIR)
    if not os.path.isdir(src):
        raise FileNotFoundError(f"Chrome profile not found: {src}")

    dst_root    = PROFILE_CACHE_ROOT
    dst_profile = os.path.join(dst_root, PROFILE_DIR)

    if refresh and os.path.isdir(dst_root):
        print(f"   Refreshing automation profile: {dst_root}")
        shutil.rmtree(dst_root, ignore_errors=True)

    if os.path.isdir(dst_profile):
        print(f"   Reusing automation profile: {dst_root}")
        remove_chrome_locks(dst_root)
        return dst_root

    os.makedirs(dst_root, exist_ok=True)
    local_state = os.path.join(USER_DATA_DIR, "Local State")
    if os.path.exists(local_state):
        shutil.copy2(local_state, os.path.join(dst_root, "Local State"))

    print(f"   Copying Profile 2 → {dst_root}")
    shutil.copytree(src, dst_profile, ignore=lambda _d, ns: [n for n in ns if n in CACHE_NAMES])
    return dst_root

def launch_chrome(chrome_exe, user_data_dir, port):
    args = [
        chrome_exe,
        f"--user-data-dir={user_data_dir}",
        f"--profile-directory={PROFILE_DIR}",
        "--remote-debugging-host=127.0.0.1",
        f"--remote-debugging-port={port}",
        "--remote-allow-origins=*",
        "--window-size=1280,800",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-popup-blocking",
        "--disable-infobars",
        "--disable-notifications",
        "--disable-dev-shm-usage",
        "--no-sandbox",
        "about:blank",
    ]
    return subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

async def wait_for_debug_endpoint(port, timeout=45):
    url  = f"http://127.0.0.1:{port}/json/version"
    loop = asyncio.get_running_loop()
    for _ in range(timeout * 4):          # check every 250 ms instead of 500 ms
        try:
            return await loop.run_in_executor(
                None,
                lambda: json.loads(urllib.request.urlopen(url, timeout=2).read()),
            )
        except Exception:
            await asyncio.sleep(0.25)
    raise TimeoutError(f"Chrome debug endpoint never opened on port {port}")

async def debug_endpoint_is_open(port):
    try:
        await wait_for_debug_endpoint(port, timeout=1)
        return True
    except Exception:
        return False

async def start_controlled_browser(args, chrome_exe):
    import nodriver as uc

    if await debug_endpoint_is_open(args.port):
        print(f"   Reusing open automation Chrome on port {args.port}")
        return await uc.start(host="127.0.0.1", port=args.port), None, None

    if args.live_profile:
        user_data_dir = USER_DATA_DIR
        if args.kill_chrome:
            kill_chrome()
            print("   Waiting 4s for Chrome to fully exit...")
            await asyncio.sleep(4)
            remove_profile_lock()
    else:
        user_data_dir = copy_profile_for_automation(refresh=args.refresh_profile)

    print(f"   Launching Chrome on debug port {args.port}")
    process = launch_chrome(chrome_exe, user_data_dir, args.port)
    try:
        await wait_for_debug_endpoint(args.port)
    except Exception:
        if process.poll() is None:
            process.terminate()
        raise

    return await uc.start(host="127.0.0.1", port=args.port), process, None

# ──────────────────────────────────────────────
# JSON / URL HELPERS
# ──────────────────────────────────────────────

def extract_json(text):
    text = (text or "").strip()
    if not text:
        raise ValueError("Empty page content")
    if text[0] in "{[":
        return json.loads(text)
    s = text.find("{");  e = text.rfind("}") + 1
    if s == -1 or e <= s:
        raise ValueError("No JSON object found in page")
    return json.loads(text[s:e])

def get_play_url(data):
    if isinstance(data, dict):
        for key in ("link", "url", "file", "src", "stream"):
            v = data.get(key)
            if isinstance(v, str) and v.startswith(("http://", "https://")):
                return v
        for key in ("sources", "tracks", "streams"):
            items = data.get(key)
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, str) and item.startswith(("http://", "https://")):
                        return item
                    if isinstance(item, dict):
                        nested = get_play_url(item)
                        if nested:
                            return nested
    elif isinstance(data, list):
        for item in data:
            nested = get_play_url(item)
            if nested:
                return nested
    return None

def read_api_urls(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"API URL list not found: {path}")
    urls = [l.strip() for l in open(path, encoding="utf-8") if l.strip() and not l.startswith("#")]
    if not urls:
        raise ValueError(f"No API URLs found in: {path}")
    return urls

def cookie_matches_host(cookie, host):
    domain = (getattr(cookie, "domain", "") or "").lstrip(".").lower()
    host   = (host or "").lower()
    return host == domain or host.endswith(f".{domain}")

# ──────────────────────────────────────────────
# FAST JSON WAITER  (polls at 100 ms, not 500 ms)
# ──────────────────────────────────────────────

async def wait_for_json_fast(page, timeout=45, blank_timeout=1):
    """Poll every 100 ms; bail out as soon as body starts with { or [."""
    deadline = time.monotonic() + timeout
    started = time.monotonic()
    last_text = ""
    tick = 0
    while time.monotonic() < deadline:
        await asyncio.sleep(0.1)
        tick += 1
        try:
            text = await page.evaluate("document.body.innerText")
            last_text = (text or "").strip()
            if last_text and last_text[0] in "{[":
                return last_text

            if tick % 10 == 0:
                title = await page.evaluate("document.title")
                if title == "" and time.monotonic() - started >= blank_timeout:
                    raise ValueError("Blank page stalled before JSON")
        except ValueError:
            raise
        except Exception:
            pass
        # Print a status line every ~5 s
        if tick % 50 == 0:
            elapsed = int(time.monotonic() - (deadline - timeout))
            try:
                title = await page.evaluate("document.title")
                print(f"      [{elapsed:02d}s] title='{title}'")
            except Exception:
                print(f"      [{elapsed:02d}s] waiting…")

    return last_text   # return whatever we have on timeout

# ──────────────────────────────────────────────
# PER-TAB WORKER
# ──────────────────────────────────────────────

_print_lock = asyncio.Lock()   # set up in main

async def safe_print(*a, **kw):
    async with _print_lock:
        print(*a, **kw)

async def extract_one(browser, api_url, timeout, blank_timeout, reloads, sem, index, total):
    """Open one tab, reload it on failure, then close it. Semaphore controls concurrency."""
    async with sem:
        label = f"[{index:>3}/{total}]"
        await safe_print(f"{label} → {api_url}")

        try:
            page = await browser.get(api_url, new_tab=True)
        except Exception as e:
            await safe_print(f"{label} ✗ open tab failed: {e}")
            return {"index": index, "api_url": api_url, "error": str(e), "extracted_url": None}

        last_error = None
        try:
            for attempt in range(reloads + 1):
                if attempt:
                    await safe_print(f"{label} ↻ immediate reload {attempt}/{reloads}")
                    await page.reload(ignore_cache=True)
                    await asyncio.sleep(0.2)

                try:
                    text = await wait_for_json_fast(page, timeout=timeout, blank_timeout=blank_timeout)

                    if not text or text[0] not in "{[":
                        # Try innerHTML fallback (rare)
                        text = await page.evaluate("document.body.innerHTML")

                    data     = extract_json(text)
                    play_url = get_play_url(data)

                    if play_url:
                        await safe_print(f"{label} ✓ {play_url}")
                        return {"index": index, "api_url": api_url, "data": data, "extracted_url": play_url}

                    last_error = "no URL in response"
                    await safe_print(f"{label} ✗ {last_error}")

                except Exception as e:
                    last_error = str(e)
                    await safe_print(f"{label} ✗ {last_error}")

            return {"index": index, "api_url": api_url, "error": last_error or "failed", "extracted_url": None}

        finally:
            try:
                await page.close()
            except Exception:
                pass

async def process_batch(browser, indexed_urls, total, timeout, blank_timeout, reloads, title):
    print(f"\n{title}: opening {len(indexed_urls)} URL(s)")
    sem = asyncio.Semaphore(max(1, len(indexed_urls)))
    tasks = [
        asyncio.create_task(
            extract_one(
                browser,
                url,
                timeout,
                blank_timeout,
                reloads,
                sem,
                index,
                total,
            )
        )
        for index, url in indexed_urls
    ]
    return await asyncio.gather(*tasks)

# ──────────────────────────────────────────────
# MAIN RUNNER
# ──────────────────────────────────────────────

async def run(args):
    global _print_lock
    _print_lock = asyncio.Lock()

    browser        = None
    chrome_process = None

    try:
        if args.batch_size < 1:
            raise ValueError("--batch-size must be at least 1")
        if args.reloads < 0:
            raise ValueError("--reloads cannot be negative")
        if args.final_retries < 0:
            raise ValueError("--final-retries cannot be negative")

        api_urls   = [args.url] if args.url else read_api_urls(args.input)
        chrome_exe = get_chrome_exe()

        print(f"Input    : {'--url' if args.url else args.input}")
        print(f"Targets  : {len(api_urls)}")
        print(f"Warm-up  : first URL opens alone")
        print(f"Batch    : {args.batch_size} URLs at a time")
        print(f"Reloads  : {args.reloads} per failed/opened URL")
        print(f"Final try: {args.final_retries} fresh retry pass")
        print(f"Timeout  : {args.timeout}s per URL")
        print(f"Chrome   : {chrome_exe}")
        print(f"Profile  : {USER_DATA_DIR}\\{PROFILE_DIR}")

        print("\nStarting Chrome…")
        browser, chrome_process, _ = await start_controlled_browser(args, chrome_exe)

        t_start = time.monotonic()
        results = []

        first = [(1, api_urls[0])]
        results.extend(
            await process_batch(
                browser,
                first,
                len(api_urls),
                args.timeout,
                args.blank_timeout,
                args.reloads,
                "Warm-up 1/1",
            )
        )

        remaining = list(enumerate(api_urls[1:], 2))
        batch_total = (len(remaining) + args.batch_size - 1) // args.batch_size
        for batch_number, batch_start in enumerate(range(0, len(remaining), args.batch_size), 1):
            batch = remaining[batch_start:batch_start + args.batch_size]
            results.extend(
                await process_batch(
                    browser,
                    batch,
                    len(api_urls),
                    args.timeout,
                    args.blank_timeout,
                    args.reloads,
                    f"Batch {batch_number}/{batch_total}",
                )
            )

        for attempt in range(1, args.final_retries + 1):
            failed = [
                (item["index"], item["api_url"])
                for item in results
                if not item.get("extracted_url")
            ]
            if not failed:
                break

            retry_results = await process_batch(
                browser,
                failed,
                len(api_urls),
                args.timeout,
                args.blank_timeout,
                0,
                f"Final retry {attempt}/{args.final_retries}",
            )
            retry_by_index = {item["index"]: item for item in retry_results}
            results = [
                retry_by_index.get(item["index"], item)
                if not item.get("extracted_url")
                else item
                for item in results
            ]

        results.sort(key=lambda item: item.get("index", 0))

        elapsed = time.monotonic() - t_start
        print(f"\n{'='*60}")
        print(f"EXTRACTED URLS  ({elapsed:.1f}s total)")
        print("="*60)
        for item in results:
            if item.get("extracted_url"):
                print(item["extracted_url"])
            else:
                print(f"FAILED : {item['api_url']}  ({item.get('error','no URL')})")
        print("="*60)

        if not args.keep_open:
            await _close(browser, chrome_process)
            browser = chrome_process = None

        return results

    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}")
    except ImportError:
        print("nodriver not installed — run:  pip install nodriver")
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback; traceback.print_exc()
    finally:
        if browser and not args.keep_open:
            await _close(browser, chrome_process)

async def _close(browser, proc):
    try:
        print("\nClosing browser…")
        browser.stop()
        await asyncio.sleep(0.8)
    except Exception:
        pass
    if proc and proc.poll() is None:
        try:
            proc.terminate()
        except Exception:
            pass

# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="PrimeSrc fast parallel URL extractor")
    p.add_argument("--input",          default=API_URL_LIST,
                   help="Text file with one API URL per line")
    p.add_argument("--url",            help="Single API URL (overrides --input)")
    p.add_argument("--port",           type=int, default=DEBUG_PORT,
                   help="Chrome remote-debug port (default 9222)")
    p.add_argument("--timeout",        type=int, default=45,
                   help="Seconds to wait for JSON per URL (default 45)")
    p.add_argument("--blank-timeout",  type=int, default=1,
                   help="Seconds to wait before immediately reloading a blank stalled tab (default 1)")
    p.add_argument("--batch-size", "--workers", dest="batch_size", type=int, default=5,
                   help="Number of URLs to open at one time (default 5)")
    p.add_argument("--reloads", "--retries", dest="reloads", type=int, default=2,
                   help="Reload the same opened tab this many times when JSON/link is missing (default 2)")
    p.add_argument("--final-retries", type=int, default=1,
                   help="Fresh final retry passes for URLs still failed after reloads (default 1)")
    p.add_argument("--refresh-profile",action="store_true",
                   help="Rebuild the cached automation profile from Profile 2")
    p.add_argument("--live-profile",   action="store_true",
                   help="Use the live Chrome user-data directory (not a copy)")
    p.add_argument("--kill-chrome",    action="store_true",
                   help="Force-close Chrome before starting (live-profile mode)")
    p.add_argument("--keep-open",      action="store_true",
                   help="Leave Chrome open after extraction")
    return p.parse_args()

async def main():
    args = parse_args()
    print("\nPRIMESRC FAST EXTRACTOR — parallel edition")
    print("="*60)
    await run(args)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted")
    sys.exit(0)
