import argparse
import asyncio
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import warnings

warnings.filterwarnings("ignore", category=ResourceWarning)

BASE_DIR = os.path.dirname(__file__)
EMBED_INPUT = os.path.join(BASE_DIR, "multiple_primesrc.txt")
API_URL_LIST = os.path.join(BASE_DIR, "api_url_list.txt")
FINAL_OUTPUT = os.path.join(BASE_DIR, "final_stream_urls.txt")

USER_DATA_DIR = r"C:\Users\AC\AppData\Local\Google\Chrome\User Data"
PROFILE_DIR = "Profile 2"
CHROME_EXE = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
CHROME_EXE_ALT = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
DEBUG_PORT = 9222
PROFILE_CACHE_ROOT = os.path.join(tempfile.gettempdir(), "primesrc_profile_cache")

CACHE_NAMES = {
    "AutofillAiModelCache", "Cache", "CacheStorage", "Code Cache",
    "DawnGraphiteCache", "DawnWebGPUCache", "GPUCache", "GrShaderCache",
    "LOCK", "LOG", "LOG.old", "optimization_guide_hint_cache_store",
    "ShaderCache", "SingletonCookie", "SingletonLock", "SingletonSocket",
}


def read_lines(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Input file not found: {path}")
    rows = []
    with open(path, "r", encoding="utf-8") as file:
        for line in file:
            line = line.strip()
            if line and not line.startswith("#"):
                rows.append(line)
    if not rows:
        raise ValueError(f"No URLs found in: {path}")
    return rows


def write_lines(path, rows):
    with open(path, "w", encoding="utf-8", newline="\n") as file:
        for row in rows:
            file.write(row + "\n")


def unique_keep_order(rows):
    seen = set()
    out = []
    for row in rows:
        if row in seen:
            continue
        seen.add(row)
        out.append(row)
    return out


def get_chrome_exe():
    for exe in (CHROME_EXE, CHROME_EXE_ALT):
        if os.path.exists(exe):
            return exe
    raise FileNotFoundError("Chrome not found at default locations.")


def remove_chrome_locks(user_data_dir):
    for rel in (
        "SingletonLock", "SingletonCookie", "SingletonSocket",
        os.path.join(PROFILE_DIR, "SingletonLock"),
        os.path.join(PROFILE_DIR, "SingletonCookie"),
        os.path.join(PROFILE_DIR, "SingletonSocket"),
        os.path.join(PROFILE_DIR, "LOCK"),
    ):
        path = os.path.join(user_data_dir, rel)
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass


def copy_profile_for_automation(refresh=False):
    src = os.path.join(USER_DATA_DIR, PROFILE_DIR)
    if not os.path.isdir(src):
        raise FileNotFoundError(f"Chrome profile not found: {src}")

    dst_root = PROFILE_CACHE_ROOT
    dst_profile = os.path.join(dst_root, PROFILE_DIR)

    if refresh and os.path.isdir(dst_root):
        print(f"   Refreshing automation profile: {dst_root}")
        shutil.rmtree(dst_root, ignore_errors=True)

    if os.path.isdir(dst_profile):
        print(f"   Reusing automation profile: {dst_root}")
        remove_chrome_locks(dst_root)
        return dst_root

    os.makedirs(dst_root, exist_ok=True)
    local_state = os.path.join(USER_DATA_DIR, "Local State")
    if os.path.exists(local_state):
        shutil.copy2(local_state, os.path.join(dst_root, "Local State"))

    print(f"   Copying Profile 2 to {dst_root}")
    shutil.copytree(
        src,
        dst_profile,
        ignore=lambda _d, names: [name for name in names if name in CACHE_NAMES],
    )
    return dst_root


def launch_chrome(chrome_exe, user_data_dir, port):
    args = [
        chrome_exe,
        f"--user-data-dir={user_data_dir}",
        f"--profile-directory={PROFILE_DIR}",
        "--remote-debugging-host=127.0.0.1",
        f"--remote-debugging-port={port}",
        "--remote-allow-origins=*",
        "--window-size=1280,800",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-popup-blocking",
        "--disable-infobars",
        "--disable-notifications",
        "--disable-dev-shm-usage",
        "--no-sandbox",
        "about:blank",
    ]
    return subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


async def wait_for_debug_endpoint(port, timeout=45):
    url = f"http://127.0.0.1:{port}/json/version"
    loop = asyncio.get_running_loop()
    for _ in range(timeout * 4):
        try:
            return await loop.run_in_executor(
                None,
                lambda: json.loads(urllib.request.urlopen(url, timeout=2).read()),
            )
        except Exception:
            await asyncio.sleep(0.25)
    raise TimeoutError(f"Chrome debug endpoint never opened on port {port}")


async def debug_endpoint_is_open(port):
    try:
        await wait_for_debug_endpoint(port, timeout=1)
        return True
    except Exception:
        return False


async def start_browser(args):
    import nodriver as uc

    if await debug_endpoint_is_open(args.port):
        print(f"   Reusing open automation Chrome on port {args.port}")
        return await uc.start(host="127.0.0.1", port=args.port), None

    user_data_dir = copy_profile_for_automation(refresh=args.refresh_profile)
    print(f"   Launching Chrome on debug port {args.port}")
    process = launch_chrome(get_chrome_exe(), user_data_dir, args.port)
    try:
        await wait_for_debug_endpoint(args.port)
    except Exception:
        if process.poll() is None:
            process.terminate()
        raise
    return await uc.start(host="127.0.0.1", port=args.port), process


async def close_browser(browser, proc):
    try:
        print("\nClosing browser...")
        browser.stop()
        await asyncio.sleep(0.8)
    except Exception:
        pass
    if proc and proc.poll() is None:
        try:
            proc.terminate()
        except Exception:
            pass


def build_server_api_url(embed_url):
    parsed = urllib.parse.urlparse(embed_url)
    params = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
    if parsed.path.startswith("/embed/movie"):
        params.setdefault("type", "movie")
    elif parsed.path.startswith("/embed/tv"):
        params.setdefault("type", "tv")
    elif "type" not in params:
        raise ValueError(f"Cannot infer movie/tv type from URL: {embed_url}")
    base = f"{parsed.scheme or 'https'}://{parsed.netloc or 'primesrc.me'}"
    return f"{base}/api/v1/s?{urllib.parse.urlencode(params)}"


def extract_json(text):
    text = (text or "").strip()
    if not text:
        raise ValueError("Empty page content")
    if text[0] in "{[":
        return json.loads(text)
    start = text.find("{")
    end = text.rfind("}") + 1
    if start == -1 or end <= start:
        raise ValueError("No JSON object found in page")
    return json.loads(text[start:end])


def get_play_url(data):
    if isinstance(data, dict):
        for key in ("link", "url", "file", "src", "stream"):
            value = data.get(key)
            if isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        for key in ("sources", "tracks", "streams"):
            values = data.get(key)
            if isinstance(values, list):
                for item in values:
                    nested = get_play_url(item)
                    if nested:
                        return nested
    elif isinstance(data, list):
        for item in data:
            nested = get_play_url(item)
            if nested:
                return nested
    elif isinstance(data, str) and data.startswith(("http://", "https://")):
        return data
    return None


def extract_api_urls_from_server_data(data):
    keys = []

    def walk(obj):
        if isinstance(obj, dict):
            key = obj.get("key")
            if isinstance(key, str) and key.strip():
                keys.append(key.strip())
            for value in obj.values():
                walk(value)
        elif isinstance(obj, list):
            for item in obj:
                walk(item)
        elif isinstance(obj, str):
            for match in re.finditer(r"/api/v1/l\?key=([A-Za-z0-9_-]+)", obj):
                keys.append(match.group(1))
            for match in re.finditer(r"https://primesrc\.me/api/v1/l\?key=([A-Za-z0-9_-]+)", obj):
                keys.append(match.group(1))

    walk(data)
    return unique_keep_order([
        f"https://primesrc.me/api/v1/l?key={urllib.parse.quote(key, safe='')}"
        for key in keys
    ])


async def wait_for_json(page, timeout=45, blank_timeout=1):
    deadline = time.monotonic() + timeout
    started = time.monotonic()
    last_text = ""
    tick = 0
    while time.monotonic() < deadline:
        await asyncio.sleep(0.1)
        tick += 1
        try:
            text = await page.evaluate("document.body.innerText")
            last_text = (text or "").strip()
            if last_text and last_text[0] in "{[":
                return last_text
            if tick % 10 == 0:
                title = await page.evaluate("document.title")
                if title == "" and time.monotonic() - started >= blank_timeout:
                    raise ValueError("Blank page stalled before JSON")
        except ValueError:
            raise
        except Exception:
            pass
    return last_text


async def load_json_with_reloads(page, timeout, blank_timeout, reloads, label):
    last_error = None
    for attempt in range(reloads + 1):
        if attempt:
            print(f"{label} reload {attempt}/{reloads}")
            await page.reload(ignore_cache=True)
            await asyncio.sleep(0.2)
        try:
            text = await wait_for_json(page, timeout=timeout, blank_timeout=blank_timeout)
            if not text or text[0] not in "{[":
                text = await page.evaluate("document.body.innerHTML")
            return extract_json(text)
        except Exception as exc:
            last_error = exc
            print(f"{label} failed: {exc}")
    raise last_error or ValueError("Failed to load JSON")


async def extract_api_urls_for_embed(browser, embed_url, args, index, total):
    label = f"[API {index:>3}/{total}]"
    server_api = build_server_api_url(embed_url)
    print(f"{label} {embed_url}")
    page = None
    try:
        page = await browser.get(server_api, new_tab=True)
        data = await load_json_with_reloads(page, args.timeout, args.blank_timeout, args.reloads, label)
        urls = extract_api_urls_from_server_data(data)
        print(f"{label} found {len(urls)} api URL(s)")
        return {"embed_url": embed_url, "server_api": server_api, "api_urls": urls}
    except Exception as exc:
        print(f"{label} ERROR: {exc}")
        return {"embed_url": embed_url, "server_api": server_api, "api_urls": [], "error": str(exc)}
    finally:
        if page:
            try:
                await page.close()
            except Exception:
                pass


async def extract_stream_from_api(browser, api_url, args, index, total):
    label = f"[STR {index:>3}/{total}]"
    print(f"{label} -> {api_url}")
    page = None
    try:
        page = await browser.get(api_url, new_tab=True)
        data = await load_json_with_reloads(page, args.timeout, args.blank_timeout, args.reloads, label)
        stream_url = get_play_url(data)
        if not stream_url:
            raise ValueError("No stream link found")
        print(f"{label} OK {stream_url}")
        return {"index": index, "api_url": api_url, "stream_url": stream_url, "data": data}
    except Exception as exc:
        print(f"{label} ERROR: {exc}")
        return {"index": index, "api_url": api_url, "stream_url": "", "error": str(exc)}
    finally:
        if page:
            try:
                await page.close()
            except Exception:
                pass


async def run_batch(items, worker):
    tasks = [asyncio.create_task(worker(*item)) for item in items]
    return await asyncio.gather(*tasks)


async def stage_api_urls(browser, embed_urls, args):
    print("\nSTAGE 1: embed URL -> api key URL")
    print("=" * 60)
    all_results = []
    if not embed_urls:
        return all_results

    all_results.extend(await run_batch(
        [(embed_urls[0], args, 1, len(embed_urls))],
        lambda url, a, i, t: extract_api_urls_for_embed(browser, url, a, i, t),
    ))

    remaining = list(enumerate(embed_urls[1:], 2))
    for start in range(0, len(remaining), args.batch_size):
        batch = remaining[start:start + args.batch_size]
        all_results.extend(await run_batch(
            [(url, args, index, len(embed_urls)) for index, url in batch],
            lambda url, a, i, t: extract_api_urls_for_embed(browser, url, a, i, t),
        ))

    return all_results


async def stage_stream_urls(browser, api_urls, args):
    print("\nSTAGE 2: api key URL -> final stream URL")
    print("=" * 60)
    results = []
    if not api_urls:
        return results

    results.extend(await run_batch(
        [(api_urls[0], args, 1, len(api_urls))],
        lambda url, a, i, t: extract_stream_from_api(browser, url, a, i, t),
    ))

    remaining = list(enumerate(api_urls[1:], 2))
    for start in range(0, len(remaining), args.batch_size):
        batch = remaining[start:start + args.batch_size]
        results.extend(await run_batch(
            [(url, args, index, len(api_urls)) for index, url in batch],
            lambda url, a, i, t: extract_stream_from_api(browser, url, a, i, t),
        ))

    for attempt in range(1, args.final_retries + 1):
        failed = [(item["api_url"], args, item["index"], len(api_urls)) for item in results if not item.get("stream_url")]
        if not failed:
            break
        print(f"\nFinal stream retry {attempt}/{args.final_retries}: {len(failed)} URL(s)")
        retry_results = await run_batch(
            failed,
            lambda url, a, i, t: extract_stream_from_api(browser, url, a, i, t),
        )
        retry_by_index = {item["index"]: item for item in retry_results}
        results = [retry_by_index.get(item["index"], item) if not item.get("stream_url") else item for item in results]

    results.sort(key=lambda item: item["index"])
    return results


async def main_async(args):
    embed_urls = read_lines(args.input)
    browser = None
    proc = None
    started = time.monotonic()

    print("\nPRIMESRC COMBINED EXTRACTOR")
    print("=" * 60)
    print(f"Input embeds : {args.input}")
    print(f"Embed count  : {len(embed_urls)}")
    print(f"API output   : {args.api_output}")
    print(f"Final output : {args.final_output}")
    print(f"Batch size   : {args.batch_size}")
    print(f"Reloads      : {args.reloads}")
    print(f"Final retry  : {args.final_retries}")

    try:
        print("\nStarting Chrome...")
        browser, proc = await start_browser(args)

        api_stage = await stage_api_urls(browser, embed_urls, args)
        api_urls = unique_keep_order([url for item in api_stage for url in item.get("api_urls", [])])
        write_lines(args.api_output, api_urls)

        print("\nAPI URLS")
        print("=" * 60)
        for url in api_urls:
            print(url)
        print("=" * 60)
        print(f"Saved {len(api_urls)} API URL(s) to {args.api_output}")

        stream_stage = await stage_stream_urls(browser, api_urls, args)
        final_urls = [item["stream_url"] for item in stream_stage if item.get("stream_url")]
        write_lines(args.final_output, final_urls)

        print("\nFINAL STREAM URLS")
        print("=" * 60)
        for item in stream_stage:
            if item.get("stream_url"):
                print(item["stream_url"])
            else:
                print(f"FAILED: {item['api_url']} ({item.get('error', 'unknown error')})")
        print("=" * 60)
        print(f"Saved {len(final_urls)} stream URL(s) to {args.final_output}")
        print(f"Finished in {time.monotonic() - started:.1f}s")
    finally:
        if browser and not args.keep_open:
            await close_browser(browser, proc)


def parse_args():
    parser = argparse.ArgumentParser(description="Combined PrimeSrc embed -> API URL -> stream URL extractor")
    parser.add_argument("--input", default=EMBED_INPUT, help="File with one PrimeSrc embed URL per line")
    parser.add_argument("--api-output", default=API_URL_LIST, help="Where extracted /api/v1/l URLs are saved")
    parser.add_argument("--final-output", default=FINAL_OUTPUT, help="Where final stream URLs are saved")
    parser.add_argument("--port", type=int, default=DEBUG_PORT, help="Chrome remote debug port")
    parser.add_argument("--timeout", type=int, default=45, help="Seconds to wait for JSON")
    parser.add_argument("--blank-timeout", type=int, default=1, help="Seconds before reloading a blank stalled page")
    parser.add_argument("--batch-size", type=int, default=5, help="Open this many URLs at a time after first warm-up URL")
    parser.add_argument("--reloads", type=int, default=2, help="Reload each failed opened tab this many times")
    parser.add_argument("--final-retries", type=int, default=1, help="Final fresh retry passes for failed stream API URLs")
    parser.add_argument("--refresh-profile", action="store_true", help="Rebuild cached automation Chrome profile")
    parser.add_argument("--keep-open", action="store_true", help="Leave Chrome open after extraction")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.batch_size < 1:
        raise SystemExit("--batch-size must be at least 1")
    if args.reloads < 0:
        raise SystemExit("--reloads cannot be negative")
    if args.final_retries < 0:
        raise SystemExit("--final-retries cannot be negative")
    asyncio.run(main_async(args))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted")
        sys.exit(130)
