"""
mitmproxy Full HTTPS Interception & API Discovery Toolkit
==========================================================
Usage:
  mitmproxy -s mitm_toolkit.py                  # Interactive TUI
  mitmdump  -s mitm_toolkit.py                  # Headless / CI
  mitmweb   -s mitm_toolkit.py                  # Web UI

Environment variables (all optional):
  MITM_FILTER        regex applied to request URLs   (default: .*)
  MITM_OUTFILE       path for JSONL output            (default: mitm_captured.jsonl)
  MITM_REPLAY_FILE   path to a saved JSONL to replay  (default: none)
  MITM_STRIP_HEADERS comma-separated headers to strip from requests
"""

import base64
import gzip
import json
import os
import re
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs, urlparse

from mitmproxy import ctx, http, websocket
from mitmproxy.connection import TransportProtocol

# ─── Config ───────────────────────────────────────────────────────────────────

URL_FILTER      = re.compile(os.getenv("MITM_FILTER", r".*"))
OUTFILE         = Path(os.getenv("MITM_OUTFILE", "mitm_captured.jsonl"))
REPLAY_FILE     = os.getenv("MITM_REPLAY_FILE", "")
STRIP_HEADERS   = [h.strip().lower()
                   for h in os.getenv("MITM_STRIP_HEADERS", "").split(",") if h.strip()]

# Headers that almost always carry auth tokens / API keys
AUTH_HEADER_PATTERNS = re.compile(
    r"^(authorization|x-api-key|x-auth-token|api[_-]key|bearer|access[_-]token"
    r"|x-amz-security-token|x-goog-api-key|x-stripe-client|x-shopify-access-token"
    r"|x-hasura-admin-secret|x-forwarded-authorization|cookie)$",
    re.IGNORECASE,
)

# Patterns for signed CDN / presigned S3 URLs
SIGNED_URL_PATTERNS = [
    re.compile(r"X-Amz-Signature="),          # AWS S3
    re.compile(r"[?&]sig="),                   # Azure Blob
    re.compile(r"[?&]token="),                 # generic token param
    re.compile(r"Expires=\d+&Signature="),     # GCS
]

_session_stats = {
    "total": 0,
    "matched": 0,
    "ws_frames": 0,
    "auth_detected": 0,
    "signed_urls": 0,
    "errors": 0,
}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _decode_body(flow_msg) -> Optional[str]:
    """Safely decode a request/response body, handling gzip."""
    raw = flow_msg.content
    if not raw:
        return None
    try:
        encoding = flow_msg.headers.get("content-encoding", "")
        if "gzip" in encoding:
            raw = gzip.decompress(raw)
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return base64.b64encode(raw).decode()


def _parse_body(body: Optional[str], content_type: str) -> object:
    if not body:
        return None
    ct = content_type.lower()
    if "json" in ct:
        try:
            return json.loads(body)
        except Exception:
            return body
    if "x-www-form-urlencoded" in ct:
        try:
            return parse_qs(body)
        except Exception:
            return body
    return body


def _extract_auth(headers: dict) -> dict:
    found = {}
    for k, v in headers.items():
        if AUTH_HEADER_PATTERNS.match(k):
            found[k] = v
    return found


def _is_signed_url(url: str) -> bool:
    return any(p.search(url) for p in SIGNED_URL_PATTERNS)


def _write_jsonl(record: dict) -> None:
    try:
        with OUTFILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
    except Exception as exc:
        ctx.log.error(f"[mitm_toolkit] JSONL write failed: {exc}")
        _session_stats["errors"] += 1


def _build_request_record(flow: http.HTTPFlow) -> dict:
    req = flow.request
    headers = dict(req.headers)
    auth     = _extract_auth(headers)
    body_raw = _decode_body(req)
    body_parsed = _parse_body(body_raw, headers.get("content-type", ""))
    parsed_url  = urlparse(req.pretty_url)

    return {
        "type":       "request",
        "ts":         _now_iso(),
        "id":         flow.id,
        "method":     req.method,
        "url":        req.pretty_url,
        "scheme":     req.scheme,
        "host":       req.pretty_host,
        "port":       req.port,
        "path":       parsed_url.path,
        "query":      dict(parse_qs(parsed_url.query)),
        "http_ver":   req.http_version,
        "headers":    headers,
        "auth_found": auth,
        "signed_url": _is_signed_url(req.pretty_url),
        "body_raw":   body_raw,
        "body":       body_parsed,
        "tls":        flow.server_conn.tls_established if flow.server_conn else False,
        "tls_sni":    flow.server_conn.tls_extensions_sni if flow.server_conn else None,
    }


def _build_response_record(flow: http.HTTPFlow) -> dict:
    resp = flow.response
    headers  = dict(resp.headers)
    body_raw = _decode_body(resp)
    body_parsed = _parse_body(body_raw, headers.get("content-type", ""))

    return {
        "type":        "response",
        "ts":          _now_iso(),
        "id":          flow.id,
        "url":         flow.request.pretty_url,
        "status":      resp.status_code,
        "reason":      resp.reason,
        "headers":     headers,
        "body_raw":    body_raw,
        "body":        body_parsed,
        "timing_ms":   round((flow.response.timestamp_end - flow.request.timestamp_start) * 1000, 2)
                       if flow.response.timestamp_end else None,
    }


# ─── Main Addon ───────────────────────────────────────────────────────────────

class MitmToolkit:
    """
    Full interception & API discovery addon.

    Capabilities:
      - HTTPS decryption (handled by mitmproxy core; this addon processes plaintext)
      - API request/response capture to JSONL
      - Auth header extraction & alerting
      - Signed CDN / presigned URL detection
      - WebSocket frame capture
      - Streaming response capture (chunked / SSE)
      - Request modification (header stripping)
      - Request replay from saved JSONL
      - Session statistics on shutdown
    """

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def running(self):
        ctx.log.info("=" * 60)
        ctx.log.info("  mitmproxy API Discovery Toolkit  –  ACTIVE")
        ctx.log.info(f"  Filter  : {URL_FILTER.pattern}")
        ctx.log.info(f"  Output  : {OUTFILE.resolve()}")
        ctx.log.info(f"  Strip   : {STRIP_HEADERS or '(none)'}")
        ctx.log.info("=" * 60)

        if REPLAY_FILE:
            self._replay_from_file(REPLAY_FILE)

    def done(self):
        ctx.log.info("=" * 60)
        ctx.log.info("  SESSION STATISTICS")
        for k, v in _session_stats.items():
            ctx.log.info(f"  {k:<20} {v}")
        ctx.log.info("=" * 60)

    # ── HTTP hooks ────────────────────────────────────────────────────────────

    def request(self, flow: http.HTTPFlow):
        _session_stats["total"] += 1

        # Strip unwanted headers before the request is forwarded
        for h in STRIP_HEADERS:
            flow.request.headers.pop(h, None)

        if not URL_FILTER.search(flow.request.pretty_url):
            return

        _session_stats["matched"] += 1
        record = _build_request_record(flow)

        # Auth alert
        if record["auth_found"]:
            _session_stats["auth_detected"] += 1
            ctx.log.warn(
                f"[AUTH] {flow.request.method} {flow.request.pretty_url} "
                f"→ headers: {list(record['auth_found'].keys())}"
            )

        # Signed URL alert
        if record["signed_url"]:
            _session_stats["signed_urls"] += 1
            ctx.log.warn(f"[SIGNED-URL] {flow.request.pretty_url}")

        _write_jsonl(record)
        ctx.log.info(
            f"[REQ] {flow.request.method} {flow.request.pretty_url} "
            f"(auth={'yes' if record['auth_found'] else 'no'}, "
            f"signed={record['signed_url']})"
        )

    def response(self, flow: http.HTTPFlow):
        if not URL_FILTER.search(flow.request.pretty_url):
            return

        record = _build_response_record(flow)
        _write_jsonl(record)
        ctx.log.info(
            f"[RES] {flow.response.status_code} {flow.request.pretty_url} "
            f"({record['timing_ms']} ms)"
        )

    # ── WebSocket hooks ───────────────────────────────────────────────────────

    def websocket_start(self, flow: http.HTTPFlow):
        ctx.log.info(f"[WS-OPEN] {flow.request.pretty_url}")
        _write_jsonl({
            "type": "ws_open",
            "ts":   _now_iso(),
            "id":   flow.id,
            "url":  flow.request.pretty_url,
        })

    def websocket_message(self, flow: http.HTTPFlow):
        _session_stats["ws_frames"] += 1
        msg = flow.websocket.messages[-1]
        content = msg.content
        if isinstance(content, bytes):
            try:
                content = content.decode("utf-8")
            except Exception:
                content = base64.b64encode(content).decode()

        record = {
            "type":      "ws_frame",
            "ts":        _now_iso(),
            "id":        flow.id,
            "url":       flow.request.pretty_url,
            "direction": "client→server" if msg.from_client else "server→client",
            "content":   content,
        }
        _write_jsonl(record)
        ctx.log.info(
            f"[WS] {record['direction']} "
            f"{str(content)[:120]}"
        )

    def websocket_end(self, flow: http.HTTPFlow):
        ctx.log.info(f"[WS-CLOSE] {flow.request.pretty_url}")

    # ── Error hook ────────────────────────────────────────────────────────────

    def error(self, flow: http.HTTPFlow):
        _session_stats["errors"] += 1
        ctx.log.error(f"[ERR] {flow.request.pretty_url if flow.request else '?'}: {flow.error}")
        _write_jsonl({
            "type": "error",
            "ts":   _now_iso(),
            "id":   flow.id,
            "url":  flow.request.pretty_url if flow.request else None,
            "msg":  str(flow.error),
        })

    # ── Replay ────────────────────────────────────────────────────────────────

    @staticmethod
    def _replay_from_file(path: str):
        """Replay all captured request records through the proxy."""
        import threading
        import urllib.request

        replay_path = Path(path)
        if not replay_path.exists():
            ctx.log.error(f"[REPLAY] File not found: {replay_path}")
            return

        def _do_replay():
            replayed = 0
            with replay_path.open(encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if rec.get("type") != "request":
                        continue
                    try:
                        req = urllib.request.Request(
                            url     = rec["url"],
                            method  = rec["method"],
                            headers = {k: v for k, v in rec["headers"].items()
                                       if k.lower() not in ("content-length", "transfer-encoding")},
                            data    = rec["body_raw"].encode() if rec.get("body_raw") else None,
                        )
                        with urllib.request.urlopen(req, timeout=10) as resp:
                            ctx.log.info(f"[REPLAY] {rec['method']} {rec['url']} → {resp.status}")
                        replayed += 1
                        time.sleep(0.1)  # gentle pacing
                    except Exception as exc:
                        ctx.log.warn(f"[REPLAY] {rec['url']}: {exc}")
            ctx.log.info(f"[REPLAY] Done – replayed {replayed} requests")

        threading.Thread(target=_do_replay, daemon=True).start()
        ctx.log.info(f"[REPLAY] Started from {replay_path}")


# ── Register addon ─────────────────────────────────────────────────────────────
addons = [MitmToolkit()]
